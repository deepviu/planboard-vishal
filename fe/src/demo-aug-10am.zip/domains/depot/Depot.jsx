const Depot = () => {
    return (
        <div className="main  w3-border"> 
           Depot 
        </div>
    ) 
}

export default Depot 