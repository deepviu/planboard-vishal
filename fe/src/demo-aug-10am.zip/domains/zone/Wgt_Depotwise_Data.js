export const Wgt_Depotwise_Data = [
    {
      id: 1,
      depot: "Delhi-Naraina",
      territorys: "6", 
      dealers: "116", 
      ly: "100",
      target: "126",
      target_percentage: "26",
      achieved: "60",
      achieved_percentage: "12",
    },  
    {
      id: 2,
      depot: "Ambala",
      territorys: "5", 
      dealers: "146", 
      ly: "100",
      target: "126",
      target_percentage: "26",
      achieved: "60",
      achieved_percentage: "12",
    },  

    {
      id: 3,
      depot: "Gurgaon",
      territorys: "5", 
      dealers: "146", 
      ly: "100",
      target: "126",
      target_percentage: "26",
      achieved: "60",
      achieved_percentage: "12",
    },    

    {
      id: 4,
      depot: "Jalandhar",
      territorys: "5", 
      dealers: "146", 
      ly: "100",
      target: "126",
      target_percentage: "26",
      achieved: "60",
      achieved_percentage: "12",
    },  


    {
      id: 5,
      depot: "Jammu",
      territorys: "5", 
      dealers: "146", 
      ly: "100",
      target: "126",
      target_percentage: "26",
      achieved: "60",
      achieved_percentage: "12",
    },  


    {
      id: 6,
      depot: "Ludhiana",
      territorys: "5", 
      dealers: "146", 
      ly: "100",
      target: "126",
      target_percentage: "26",
      achieved: "60",
      achieved_percentage: "12",
    },  


    {
      id: 7,
      depot: "Nebsarai",
      territorys: "5", 
      dealers: "146", 
      ly: "100",
      target: "126",
      target_percentage: "26",
      achieved: "60",
      achieved_percentage: "12",
    },    


    {
      id: 8,
      depot: "Zirakpur [Himachal]",
      territorys: "5", 
      dealers: "146", 
      ly: "100",
      target: "126",
      target_percentage: "26",
      achieved: "60",
      achieved_percentage: "12",
    },    


    {
      id: 9,
      depot: "Zirakpur",
      territorys: "5", 
      dealers: "146", 
      ly: "100",
      target: "126",
      target_percentage: "26",
      achieved: "60",
      achieved_percentage: "12",
    },  
  ];