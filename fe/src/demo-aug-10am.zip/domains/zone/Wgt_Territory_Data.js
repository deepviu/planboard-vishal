export const Wgt_Territory_Data = [
   
      {
      id: 1,
      depot: "HO2", 
      dealers: "116", 
      ly: "100",
      target: "126",
      target_percentage: "26",
      achieved: "60",
      achieved_percentage: "12",
    }, 
      {
      id: 2,
      depot: "HO4", 
      dealers: "116", 
      ly: "100",
      target: "126",
      target_percentage: "26",
      achieved: "60",
      achieved_percentage: "12",
    }, 
    {
      id: 3,
      depot: "HO7", 
      dealers: "116", 
      ly: "100",
      target: "126",
      target_percentage: "26",
      achieved: "60",
      achieved_percentage: "12",
    }, 
  ];