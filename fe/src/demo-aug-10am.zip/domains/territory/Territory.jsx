const Territory = () => {
    return (
        <div className="main  w3-border"> 
           Territory 
        </div>
    ) 
}

export default Territory 