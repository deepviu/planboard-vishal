const Dealer = () => {
    return (
        <div className="main  w3-border"> 
           Dealer 
        </div>
    ) 
}

export default Dealer 