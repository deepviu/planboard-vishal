const Notifications = () => {
    return (
        <div className="main  w3-border"> 
           Notifications 
        </div>
    ) 
}

export default Notifications 