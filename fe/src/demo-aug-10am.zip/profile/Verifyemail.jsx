const Verifyemail = () => {
    return (
        <div className="main  w3-border"> 
           Verifyemail 
        </div>
    ) 
}

export default Verifyemail 