const Account = () => {
    return (
        <div className="main  w3-border"> 
           Account 
        </div>
    ) 
}

export default Account 