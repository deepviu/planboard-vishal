 

const About = () => {
    return (
        <div className="home">
           About us
        </div>
    )
}

export default About 