import './App.css';

import { useEffect, useState, useContext } from "react"; 
import { BrowserRouter, Routes, Route, Navigate, Link, useNavigate } from "react-router-dom";
 

import { signOut } from "firebase/auth"; 
import { auth } from "./firebase";
 
 import {Navbar, Sidebar} from "./components"; 

 import {Login, Register, Forgotpassword} from "./auth"; 
 import {Account, Profile, Notifications, Logs, Verifyemail, Verifyphone, Verifyprofile} from "./profile";  
 import { Dashboard, National, Zone, Depot, Territory, Dealer, Schedule } from "./domains";  

 import {About} from "./pages";  

function App({isLogout}) {

if (isLogout)
{
   signOut(auth).then(() => {
    localStorage.clear();
    setIsAuth(false);   
  });

}; 

const [isAuth, setIsAuth] = useState(localStorage.getItem("isAuth")); 

useEffect(() => {  
 const isAuth = localStorage.getItem('isAuth')  
  }, []); 

  return ( 
    <>  
     <BrowserRouter>
      <div>
        <Navbar isAuth={isAuth} />
         <Sidebar isAuth={isAuth} />
        <Routes> 
          <Route path="*" element={isAuth ? <Navigate to="/dashboard" /> : <Login />} />  
          <Route path="/" element={isAuth ? <Navigate to="/dashboard" /> : <Login />} /> 

          <Route path="/login" element={isAuth ? <Navigate to="/" /> : <Login setIsAuth={setIsAuth} />} /> 
          <Route path="/register" element={isAuth ? <Register isAuth={isAuth}/> :  <Navigate to="/login" />} />
          <Route path="/forgotpassword" element={isAuth ? <Forgotpassword isAuth={isAuth}/> :  <Navigate to="/login" />} /> 

          <Route path="/account" element={isAuth ? <Account isAuth={isAuth}/> :  <Navigate to="/login" />} /> 
          <Route path="/profile" element={isAuth ? <Profile isAuth={isAuth}/> :  <Navigate to="/login" />} /> 
          <Route path="/notifications" element={isAuth ? <Notifications isAuth={isAuth}/> :  <Navigate to="/login" />} />
          <Route path="/logs" element={isAuth ? <Logs isAuth={isAuth}/> :  <Navigate to="/login" />} /> 

          <Route path="/verifyphone" element={isAuth ? <Verifyphone isAuth={isAuth}/> :  <Navigate to="/login" />} /> 
          <Route path="/verifyemail" element={isAuth ? <Verifyemail isAuth={isAuth}/> :  <Navigate to="/login" />} /> 
          <Route path="/verifyprofile" element={isAuth ? <Verifyprofile isAuth={isAuth}/> :  <Navigate to="/login" />} /> 
           
          <Route path="/dashboard" element={isAuth ? <Dashboard isAuth={isAuth}/> :  <Navigate to="/login" />} /> 
          <Route path="/national" element={isAuth ? <National isAuth={isAuth} /> :  <Navigate to="/login" />} />
          <Route path="/zone" element={isAuth ? <Zone /> :  <Navigate to="/login" />} /> 
          <Route path="/depot" element={isAuth ? <Depot isAuth={isAuth} /> :  <Navigate to="/login" />} /> 
          <Route path="/territory" element={isAuth ? <Territory isAuth={isAuth} /> :  <Navigate to="/login" />} /> 
          <Route path="/dealer" element={isAuth ? <Dealer isAuth={isAuth} /> :  <Navigate to="/login" />} /> 
          <Route path="/schedule" element={isAuth ? <Schedule isAuth={isAuth} /> :  <Navigate to="/login" />} />  
            
          <Route path="/about" element={isAuth ? <About isAuth={isAuth} /> : <Navigate to="/login" />} /> 

        </Routes>
      </div>
    </BrowserRouter>
    </> 
  );
}

export default App; 